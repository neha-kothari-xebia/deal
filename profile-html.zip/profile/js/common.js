


 
  var customIcon = document.createElement('img');
  customIcon.src = './icon.svg';
  

  var autocomplete = new SelectPure(".autocomplete-select", {
    options: [
      {
        label: "Barbina",
        value: "ba",
      },
      {
        label: "Bigoli",
        value: "bg",
      },
      {
        label: "Bucatini",
        value: "bu",
      },
      {
        label: "Busiate",
        value: "bus",
      },
      {
        label: "Capellini",
        value: "cp",
      },
      {
        label: "Fedelini",
        value: "fe",
      },
      {
        label: "Maccheroni",
        value: "ma",
      },
      {
        label: "Pipe rigate à la crème",
        value: "pr",
      },
      {
        label: "Spaghetti",
        value: "sp",
      },
    ],
    value: ["sp"],
    multiple: true,
    autocomplete: true,
    customIcon:true,
    icon: "",
    onChange: value => { console.log(value); },
    classNames: {
      select: "select-pure__select",
      dropdownShown: "select-pure__select--opened",
      multiselect: "select-pure__select--multiple",
      label: "select-pure__label",
      placeholder: "select-pure__placeholder",
      dropdown: "select-pure__options",
      option: "select-pure__option",
      autocompleteInput: "select-pure__autocomplete",
      selectedLabel: "select-pure__selected-label",
      selectedOption: "select-pure__option--selected",
      placeholderHidden: "select-pure__placeholder--hidden",
      optionHidden: "select-pure__option--hidden",
    }
  });
  var resetAutocomplete = function() {
    autocomplete.reset();
  };

  function displayTree() {
      var treeOpen = document.getElementById("treeSelect");
    
      if (treeOpen.style.display === "none") {
        treeOpen.style.display = "block";
  } else {
    treeOpen.style.display = "none";
  }
  }




  // prettier-ignore
  let data = [{ "id": "0", "text": "node-0", "children": [{ "id": "0-0", "text": "node-0-0", "children": [{ "id": "0-0-0", "text": "node-0-0-0" }, { "id": "0-0-1", "text": "node-0-0-1" }, { "id": "0-0-2", "text": "node-0-0-2" }] }, { "id": "0-1", "text": "node-0-1", "children": [{ "id": "0-1-0", "text": "node-0-1-0" }, { "id": "0-1-1", "text": "node-0-1-1" }, { "id": "0-1-2", "text": "node-0-1-2" }] }, { "id": "0-2", "text": "node-0-2", "children": [{ "id": "0-2-0", "text": "node-0-2-0" }, { "id": "0-2-1", "text": "node-0-2-1" }, { "id": "0-2-2", "text": "node-0-2-2" }] }] }, { "id": "1", "text": "node-1", "children": [{ "id": "1-0", "text": "node-1-0", "children": [{ "id": "1-0-0", "text": "node-1-0-0" }, { "id": "1-0-1", "text": "node-1-0-1" }, { "id": "1-0-2", "text": "node-1-0-2" }] }, { "id": "1-1", "text": "node-1-1", "children": [{ "id": "1-1-0", "text": "node-1-1-0" }, { "id": "1-1-1", "text": "node-1-1-1" }, { "id": "1-1-2", "text": "node-1-1-2" }] }, { "id": "1-2", "text": "node-1-2", "children": [{ "id": "1-2-0", "text": "node-1-2-0" }, { "id": "1-2-1", "text": "node-1-2-1" }, { "id": "1-2-2", "text": "node-1-2-2" }] }] }, { "id": "2", "text": "node-2", "children": [{ "id": "2-0", "text": "node-2-0", "children": [{ "id": "2-0-0", "text": "node-2-0-0" }, { "id": "2-0-1", "text": "node-2-0-1" }, { "id": "2-0-2", "text": "node-2-0-2" }] }, { "id": "2-1", "text": "node-2-1", "children": [{ "id": "2-1-0", "text": "node-2-1-0" }, { "id": "2-1-1", "text": "node-2-1-1" }, { "id": "2-1-2", "text": "node-2-1-2" }] }, { "id": "2-2", "text": "node-2-2", "children": [{ "id": "2-2-0", "text": "node-2-2-0" }, { "id": "2-2-1", "text": "node-2-2-1" }, { "id": "2-2-2", "text": "node-2-2-2" }] }] }]
 
  let tree = new Tree('.tree-struct', {
      data: [{ id: '-1', text: 'root', children: data }],
      closeDepth: 3,
      loaded: function () {
          this.values = ['0-0-0', '0-1-1'];
          console.log(this.selectedNodes)
          console.log(this.values)
          this.disables = ['0-0-0', '0-0-1', '0-0-2']
      },
      onChange: function () {
          console.log(this.values);
          console.log(this.selectedNodes);
         
      }
     
  })



   function browseFileClick() {
      var checkBox = document.getElementById("browseFileCheck");
      var text = document.getElementById("upload");
      var uploadHide = document.getElementById("uploadHide");
      if (checkBox.checked == true) {
        text.className = 'visibleFile';
        
       // uploadHide.className = 'invisibleFile'
        // input.removeEventListener( 'change', showFileName );
        console.log("mm");
      } else {
        text.className = 'invisibleFile';
      //  uploadHide.className = 'visibleFile'
        console.log("hh");
      }
    }

    function browseFileClickSecond() {
      var checkBox = document.getElementById("checkBoxSecond");
      var text = document.getElementById("uploadSecond");
      var uploadHide = document.getElementById("uploadHideSecond");
      if (checkBox.checked == true) {
        text.className = 'visible';
       // uploadHide.className = 'invisible'
        // input.removeEventListener( 'change', showFileName );
        console.log("mm");
      } else {
        text.className = 'invisible';
       // uploadHide.className = 'visible'
        console.log("hh");
      }
    }

    var input = document.getElementById('file-upload');
    var infoArea = document.getElementById('file-upload-filename');
    var fileArea = document.getElementById('file-upload-fileupload');
    var closeArea = document.getElementById('closeFile');
    var output;
    input.addEventListener('change', showFileName);

    function showFileName(event) {

      // the change event gives us the input it occurred in 
      var input = event.srcElement;

      // the input has an array of files in the `files` property, each one has a name that you can use. We're just using the name here.
      var fileName = input.files[0].name;

      // use fileName however fits your app best, i.e. add it into a div
      infoArea.textContent = ' ' + fileName;
      var lengthFile = infoArea.textContent.length;
     
      if (lengthFile !== 0){
        input.classList.add("focus-label");
        fileArea.style.display = "block";
        closeArea.style.display = "block";
      }

      
    }
    //  imgArea.src = URL.createObjectURL(event.target.files[0]);
      // fileName = imgArea.src;
     
      //       extension = fileName.substring(fileName.lastIndexOf('.') + 1);
      //      console.log(extension);
      //      output = extension.textContent;
      //        if (output !== jpeg){
      //             imgArea.style.display = "none";
      //            }
     
     
      function browseFileClose() {
        var lengthFile = {}; 
      if (lengthFile !== 0){
        infoArea.innerHTML = "";
        
      closeArea.style.display = "none";
      fileArea.style.display = "none";
      }
   
    }
  



    