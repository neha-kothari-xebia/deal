


 // custom select code
 var x, i, j, l, ll, selElmnt, a, b, c;
 /* Look for any elements with the class "custom-select": */
 x = document.getElementsByClassName("custom-select");
 l = x.length;
 for (i = 0; i < l; i++) {
   selElmnt = x[i].getElementsByTagName("select")[0];
   ll = selElmnt.length;
   /* For each element, create a new DIV that will act as the selected item: */
   a = document.createElement("DIV");
   a.setAttribute("class", "select-selected");
   a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
   x[i].appendChild(a);
   /* For each element, create a new DIV that will contain the option list: */
   b = document.createElement("DIV");
   b.setAttribute("class", "select-items select-hide");
   for (j = 1; j < ll; j++) {
     /* For each option in the original select element,
create a new DIV that will act as an option item: */
     c = document.createElement("DIV");
     c.innerHTML = selElmnt.options[j].innerHTML;
     c.addEventListener("click", function (e) {
       /* When an item is clicked, update the original select box,
 and the selected item: */
       var y, i, k, s, h, sl, yl;
       lbl = this.parentNode.parentNode.getElementsByTagName("label")[0];
       lbl.classList.add("form-control-label");
       s = this.parentNode.parentNode.getElementsByTagName("select")[0];
       sl = s.length;
       h = this.parentNode.previousSibling;
       for (i = 0; i < sl; i++) {
         if (s.options[i].innerHTML == this.innerHTML) {
           console.log("this", this.parentNode);
           this.parentNode.parentNode.classList.add("selected-font-black");
           s.selectedIndex = i;
           h.innerHTML = this.innerHTML;
           y = this.parentNode.getElementsByClassName("same-as-selected");
           yl = y.length;
           for (k = 0; k < yl; k++) {
             y[k].removeAttribute("class");
           }
           this.setAttribute("class", "same-as-selected");
           break;
         }
       }
       h.click();
     });
     b.appendChild(c);
   }
   x[i].appendChild(b);
   a.addEventListener("click", function (e) {
     /* When the select box is clicked, close any other select boxes,
and open/close the current select box: */
     e.stopPropagation();
     closeAllSelect(this);
     this.nextSibling.classList.toggle("select-hide");
     this.classList.add('selected-item');
     this.classList.toggle("select-arrow-active");
   });
 }

 function closeAllSelect(elmnt) {
   /* A function that will close all select boxes in the document,
except the current select box: */
   var x,
     y,
     i,
     xl,
     yl,
     arrNo = [];
   x = document.getElementsByClassName("select-items");
   y = document.getElementsByClassName("select-selected");
   xl = x.length;
   yl = y.length;
   for (i = 0; i < yl; i++) {
     if (elmnt == y[i]) {
       arrNo.push(i);
     } else {
       y[i].classList.remove("select-arrow-active");
     }
   }
   for (i = 0; i < xl; i++) {
     if (arrNo.indexOf(i)) {
       x[i].classList.add("select-hide");
     }
   }
 }

 function blurAllselect(elmnt) {
   var x, xl, arrNo = [];
   x = document.getElementsByClassName("select-selected");
   xl = x.length
   for (i = 0; i < xl; i++) {
     x[i].classList.remove("selected-item");
   }
 }

 /* If the user clicks anywhere outside the select box,
then close all select boxes: */
 document.addEventListener("click", blurAllselect);
 document.addEventListener("click", closeAllSelect);
 // function to add a selected value into "selected" object
 function addToSelected(elm, inputElm) {
   console.log(elm, inputElm);
   const selectedID = inputElm.parentNode.parentNode
     .getElementsByTagName("input")[0]
     .name.split("-")[0];
   if (!selected[selectedID]) {
     selected[selectedID] = [];
   }

   const hasAlready = selected[selectedID].indexOf(elm);

   if (hasAlready !== -1) {
     return;
   }
   selected[selectedID].push(elm);
   const node = document.createElement("DIV");
   node.setAttribute("class", "chip-span");
   const imageNode = document.createElement("img");
   imageNode.setAttribute("src", "../../assets/media/profile.svg");
   imageNode.setAttribute("class", "chip-image");
   const textNode = document.createElement("SPAN");
   textNode.innerText = elm;
   textNode.setAttribute("class", "chip-text");
   const crossSpan = document.createElement("BUTTON");
   crossSpan.setAttribute("class", "cross-span");
   //crossSpan.innerText = "x";

   // function to remove value from selected object
   crossSpan.addEventListener("click", function (e) {
     const toRemove = e.target.parentNode.firstChild;
     const newArr = selected[selectedID].filter(function (val) {
       return val === toRemove;
     });
     e.target.parentNode.parentNode.removeChild(
       e.target.parentNode
     );
     selected[selectedID] = newArr;
   });
   //imageNode.insertAdjacentElement("beforeend", textNode);
   //textNode.insertAdjacentElement("beforeend", crossSpan);

   node.appendChild(imageNode);
   node.appendChild(textNode);
   node.appendChild(crossSpan);
   //node.appendChild(crossSpan);
   inputElm.parentNode.parentNode.prepend(node);
 }
 const selected = {};
  var customIcon = document.createElement('img');
  customIcon.src = './icon.svg';
  

  var autocomplete = new SelectPure(".autocomplete-select", {
    options: [
      {
        label: "Barbina",
        value: "ba",
      },
      {
        label: "Bigoli",
        value: "bg",
      },
      {
        label: "Bucatini",
        value: "bu",
      },
      {
        label: "Busiate",
        value: "bus",
      },
      {
        label: "Capellini",
        value: "cp",
      },
      {
        label: "Fedelini",
        value: "fe",
      },
      {
        label: "Maccheroni",
        value: "ma",
      },
      {
        label: "Pipe rigate à la crème",
        value: "pr",
      },
      {
        label: "Spaghetti",
        value: "sp",
      },
    ],
    value: ["sp"],
    multiple: true,
    autocomplete: true,
    customIcon:true,
    icon: "",
    onChange: value => { console.log(value); },
    classNames: {
      select: "select-pure__select",
      dropdownShown: "select-pure__select--opened",
      multiselect: "select-pure__select--multiple",
      label: "select-pure__label",
      placeholder: "select-pure__placeholder",
      dropdown: "select-pure__options",
      option: "select-pure__option",
      autocompleteInput: "select-pure__autocomplete",
      selectedLabel: "select-pure__selected-label",
      selectedOption: "select-pure__option--selected",
      placeholderHidden: "select-pure__placeholder--hidden",
      optionHidden: "select-pure__option--hidden",
    }
  });
  var resetAutocomplete = function() {
    autocomplete.reset();
  };


   function browseFileClick() {
      var checkBox = document.getElementById("browseFileCheck");
      var text = document.getElementById("upload");
      var uploadHide = document.getElementById("uploadHide");
      if (checkBox.checked == true) {
        text.className = 'visibleFile';
        
       // uploadHide.className = 'invisibleFile'
        // input.removeEventListener( 'change', showFileName );
        console.log("mm");
      } else {
        text.className = 'invisibleFile';
      //  uploadHide.className = 'visibleFile'
        console.log("hh");
      }
    }

    function browseFileClickSecond() {
      var checkBox = document.getElementById("checkBoxSecond");
      var text = document.getElementById("uploadSecond");
      var uploadHide = document.getElementById("uploadHideSecond");
      if (checkBox.checked == true) {
        text.className = 'visible';
       // uploadHide.className = 'invisible'
        // input.removeEventListener( 'change', showFileName );
        console.log("mm");
      } else {
        text.className = 'invisible';
       // uploadHide.className = 'visible'
        console.log("hh");
      }
    }

    var input = document.getElementById('file-upload');
    var infoArea = document.getElementById('file-upload-filename');
    var fileArea = document.getElementById('file-upload-fileupload');
    var closeArea = document.getElementById('closeFile');
    // var output;
    // input.addEventListener('change', showFileName);

    function showFileName(event) {

      // the change event gives us the input it occurred in 
      var input = event.srcElement;

      // the input has an array of files in the `files` property, each one has a name that you can use. We're just using the name here.
      var fileName = input.files[0].name;

      // use fileName however fits your app best, i.e. add it into a div
      infoArea.textContent = ' ' + fileName;
      var lengthFile = infoArea.textContent.length;
     
      if (lengthFile !== 0){
        input.classList.add("focus-label");
        fileArea.style.display = "block";
        closeArea.style.display = "block";
      }

      
    }
    //  imgArea.src = URL.createObjectURL(event.target.files[0]);
      // fileName = imgArea.src;
     
      //       extension = fileName.substring(fileName.lastIndexOf('.') + 1);
      //      console.log(extension);
      //      output = extension.textContent;
      //        if (output !== jpeg){
      //             imgArea.style.display = "none";
      //            }
     
     
      function browseFileClose() {
        var lengthFile = {}; 
      if (lengthFile !== 0){
        infoArea.innerHTML = "";
        
      closeArea.style.display = "none";
      fileArea.style.display = "none";
      }
   
    }
  



    document.getElementById("link-require-pwd").onchange = function () {
      document.getElementById("password").disabled = !this.checked;
      if (document.getElementById("password").disabled) {
        document.getElementById("password").value = "";
        document.getElementById("passwordLabel").classList.remove("form-control-label");
      }
    };
    document.getElementById("overall-deal").onchange = function () {
      document.getElementById("lookup-accounts").disabled = !this.checked;
      if (document.getElementById("lookup-accounts").disabled) {
        document.getElementById("lookup-accounts").value = "";
        document.getElementById("lookup-accounts-label").classList.remove("form-control-label");
      }
    };
    
    document.getElementById("req-due-date").onchange = function () {
      document.getElementById("due-date").disabled = !this.checked;
    };
  
    document.getElementById("req-edit-due-date").onchange = function () {
      document.getElementById("edit-due-date").disabled = !this.checked;
    };
  
  
    var textarea = document.querySelectorAll("textarea");
    var index = 0;
    for (; index < textarea.length; index++) {
      textarea[index].addEventListener("keydown", autosize);
    }
  
    function autosize() {
      var el = this;
      setTimeout(function () {
        el.style.cssText = "height:auto; padding:0";
        el.style.cssText = "height:" + el.scrollHeight + "px";
      }, 0);
    }
  
    function displayTitle(e, isAutocomplete = false) {
      console.log(e.labels[0]);
      const elm = e.labels[0];
      if (!isAutocomplete) {
        elm.classList.add("form-control-label");
      } else {
        elm.classList.add("form-control-ac-label");
      }
      e.placeholder = " ";
    }
  
    function fillSvg(e) {
      console.log(e);
      let svgImages = e.querySelectorAll(".svg-color");
      for (i = 0; i < svgImages.length; i++) {
        svgImages[i].style.fill = "#247C4A";
        svgImages[i].classList.toggle("fill-grey");
      }
      // e.querySelector(".svg-color-red").style.fill = "#A81616";
      e.querySelector(".svg-color-red").classList.toggle("fill-grey");
    }
  
    function updateStatus(e) {
      let text = e.querySelectorAll("b");
      text[0].classList.toggle('txt-black');
    }
  
    function updateCoverageStatus(e) {
      let text = e.querySelectorAll("b");
      text[0].classList.toggle('txt-black');
      let connector = document.querySelectorAll('.submission-status');
      connector[0].classList.toggle('active');
    }

    
  
  
  
    